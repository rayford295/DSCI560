# data_exploration
Choose any publicly available dataset from data sources and types that you have chosen.  Create a python file named “data_exploration.py” to retrieve the dataset using its API and  store it in csv / excel format.  
